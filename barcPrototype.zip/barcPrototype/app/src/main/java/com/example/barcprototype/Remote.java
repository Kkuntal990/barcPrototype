package com.example.barcprototype;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Remote extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_remote);
    }
}
